<?php

namespace app\models;

use Yii;


class Main extends \yii\db\ActiveRecord
{

    public static function tableName()
    {
        return 'main';
    }


}
